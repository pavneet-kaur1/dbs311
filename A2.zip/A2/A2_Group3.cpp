/***********************
--Student1 Name : Pavneet Kaur ID : 128287216
--Student2 Name : Harpreet Singh ID : 155912207
--Student3 Name : Disha Rawat ID : 145286209
--Date : 10 / 08 / 2022
--Purpose : Assignment 2 - DBS311
 ***********************/
#include <iostream>
#include <string>
#include <occi.h>
#include <cctype>

using oracle::occi::Environment;
using oracle::occi::Connection;
//namespaces
using namespace oracle::occi;
using namespace std;
//struct
struct ShoppingCart {
	int product_id;
	double price;
	int quantity;
};
//for getting menu options
int mainMenu();
//for getting customer
int customerLogin(Connection* conn, int customerId);
//for adding items to cart
int addToCart(Connection* conn, struct ShoppingCart cart[]);
//for finding product in product list
double findProduct(Connection* conn, int product_id);
//for printing order to the screen
void displayProducts(struct ShoppingCart cart[], int productCount);
//for confirming the order
int checkout(Connection* conn, struct ShoppingCart cart[], int customerId, int productCount);
int mainMenu() {
	int option = 0;
	do {
		cout << "******************* Main Menu *******************\n"
			<< "1)\tLogin\n"
			<< "0)\tExit\n";

		if (option != 0 && option != 1) {
			cout << "You entered a wrong value. Enter an option (0-1): ";
		}
		else
			cout << "Enter an option (0-1): ";

		cin >> option;
	} while (option != 0 && option != 1);

	return option;
}

int customerLogin(Connection* conn, int customerId) {
	// for execution of SQL scripts
	Statement* stmt = conn->createStatement();

	// input parameters
	stmt->setSQL("BEGIN find_customer(:1, :2); END;");
	int found;
	//setting IN parameter of stored procedure
	stmt->setInt(1, customerId);   
	// setting type and size of the OUT parameter
	stmt->registerOutParam(2, Type::OCCIINT, sizeof(found));
	// Calling the  procedure
	stmt->executeUpdate();
	found = stmt->getInt(2);

	// Termination of  statement
	conn->terminateStatement(stmt);

	return found;	
}

int addToCart(Connection* conn, struct ShoppingCart cart[]) {
	cout << "-------------- Add Products to Cart --------------" << endl;
	for (int i = 0; i < 5; ++i) {
		int productId;//variable for product id
		int quantity; //variable for getting quantity of product to ordered
		ShoppingCart item;//variable for item
		int choose;//variable for storing the option chose 

		do {
			cout << "Enter the product ID: ";
			cin >> productId;
			//printoutput if product doesn't exist
			if (findProduct(conn, productId) == 0) {
				cout << "The product does not exist. Try again..." << endl;
			}
		} while (findProduct(conn, productId) == 0);
		//if product exists 
		cout << "Product Price: " << findProduct(conn, productId) << endl;
		cout << "Enter the product Quantity: ";
		cin >> quantity;

		item.product_id = productId;
		item.price = findProduct(conn, productId);	
		item.quantity = quantity;
		cart[i] = item;

		if (i == 4)
			return i + 1;
		else {
			do {
				//if user wants to add more products or want to checkout
				cout << "Enter 1 to add more products or 0 to check out: ";
				cin >> choose;
			} while (choose != 0 && choose != 1);
		}

		if (choose == 0)
			return i + 1;
	}
}
double findProduct(Connection* conn, int product_id) {
	// for execution of SQL scripts
	Statement* stmt = conn->createStatement();

	// input parameters
	stmt->setSQL("BEGIN find_product(:1, :2); END;");
	double price;
    //setting IN parameter of stored procedure
	stmt->setInt(1, product_id);   

	// setting type and size of the OUT parameter
	stmt->registerOutParam(2, Type::OCCIDOUBLE, sizeof(price));
	// Calling the  procedure
	stmt->executeUpdate();
    //setting the price
	price = stmt->getDouble(2);

	// Termination statement
	conn->terminateStatement(stmt);
	if (price > 0) {
		return price;
	}
	else {
		return 0;
	}
		
}
void displayProducts(struct ShoppingCart cart[], int productCount) {
	if (productCount > 0) {
		double totalPrice = 0.0;
		//print list of ordered items
		cout << "------- Ordered Products ---------" << endl;
		for (int i = 0; i < productCount; ++i) {
			cout << "---Item " << i + 1 << endl;
			cout << "Product ID: " << cart[i].product_id << endl;
			cout << "Price: " << cart[i].price << endl;
			cout << "Quantity: " << cart[i].quantity << endl;
			totalPrice += cart[i].price * cart[i].quantity;
		}
		cout << "----------------------------------\nTotal: " << totalPrice << endl;
	}
}

int checkout(Connection* conn, struct ShoppingCart cart[], int customerId, int productCount) {
	char choice;
	do {
		//if customer want to confirm order or not
		cout << "Would you like to checkout ? (Y/y or N/n) ";
		cin >> choice;

		if (choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n')
			cout << "Wrong input. Try again..." << endl;
	} while (choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n');

	if (choice == 'N' || choice == 'n') {
		cout << "The order is cancelled." << endl;
		return 0;
	}
	else {
		// for execution of SQL scripts
		Statement* stmt = conn->createStatement();
		// input parameters
		stmt->setSQL("BEGIN add_order(:1, :2); END;");
		int next_order_id;
		//setting IN parameter of stored procedure
		stmt->setInt(1, customerId);   
		// setting type and size of the OUT parameter
		stmt->registerOutParam(2, Type::OCCIINT, sizeof(next_order_id));

		// Calling the procedure
		stmt->executeUpdate();

		next_order_id = stmt->getInt(2);

		for (int i = 0; i < productCount; ++i) {
			stmt->setSQL("BEGIN add_order_item(:1, :2, :3, :4, :5); END;");

			// Setting IN parameters
			stmt->setInt(1, next_order_id);
			stmt->setInt(2, i + 1);
			stmt->setInt(3, cart[i].product_id);
			stmt->setInt(4, cart[i].quantity);
			stmt->setDouble(5, cart[i].price);

			// Calling the  procedure
			stmt->executeUpdate();
		}

		cout << "The order is successfully completed." << endl;

		// Termination statement
		conn->terminateStatement(stmt);

		return 1;
	}
}
//execution point of file
int main() {
	//connection variables
	Environment* env = nullptr;
	Connection* conn = nullptr;
	//variables for storing credentials
	string user = "dbs311_222zb13";
	string pass = "30363235";
	string constr = "myoracle12c.senecacollege.ca:1521/oracle12c";
	try {
		env = Environment::createEnvironment(Environment::DEFAULT);
		conn = env->createConnection(user, pass, constr);

		int choose;//varaible for storing the option
		int customerId;//variable for storing customer id
		do {
			choose = mainMenu();

			if (choose == 1) {
				cout << "Enter the customer ID: ";
				cin >> customerId;

				if (customerLogin(conn, customerId) == 0) {
					cout << "The customer does not exist." << endl;
				}
				else {
					ShoppingCart cart[5];
					int count = addToCart(conn, cart);
					displayProducts(cart, count);
					checkout(conn, cart, customerId, count);
				}

			}


		} while (choose != 0);

		cout << "Good bye!..." << endl;

		env->terminateConnection(conn);
		Environment::terminateEnvironment(env);
	}
	catch (SQLException& sqlExcp) {
		cout << sqlExcp.getErrorCode() << ": " << sqlExcp.getMessage();
	}
	return 0;
}


